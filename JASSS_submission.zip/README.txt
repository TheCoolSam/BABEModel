﻿JASSS submission package — Dynamic-BABE / Polarization Paradox
==============================================================

Contents
--------
pdf/main.pdf          Author-identified manuscript
pdf/main_blind.pdf    Anonymised review copy
latex/                Full LaTeX sources (compile from latex/ with pdfLaTeX + BibTeX)
figures/              Separate PNG figures (no captions in images)
latex/OVERLEAF.md     Build instructions

Code
----
Working repository: https://github.com/TheCoolSam/BABEModel
(CoMSES deposit pending — replace this line with the permanent handle when available.)

Author biographies
------------------
Still TODO in latex/main.tex (Author Biographies). Supply ~100 words per author on the ePress form and in the TeX source before final submit.

Notes
-----
- Windows: the style file is named jasssbib.bst (not jasss.bst) to avoid a case-insensitive clash with JASSS.cls.
- Logo file is jassslogo.png for the same reason; JASSS.cls in this package already points to it.
