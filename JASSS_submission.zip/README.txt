JASSS strength-upgrade package � Dynamic-BABE
See latex/OVERLEAF.md and docs/COMSES_DEPOSIT.md.
Bios/email/CoMSES URL still author gates (SUBMISSION_GATES.md).
